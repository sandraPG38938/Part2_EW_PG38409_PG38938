var mongoose = require('mongoose')
var Schema = mongoose.Schema

var ApostaSchema = new Schema({
    estado: {type: String}, // aberto ou fechado
    aposta: {type: String}, //aposta do jogador
    data: {type: String}, //data da aposta
   
    jogadorID: {type: String},
    jogadorNome: {type: String},
    eventoID: {type: String},
    eventoNome: {type: String},
    eventoResultado: {type: String}
})

module.exports = mongoose.model('Aposta', ApostaSchema)
