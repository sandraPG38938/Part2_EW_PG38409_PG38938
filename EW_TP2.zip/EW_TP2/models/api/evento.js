var mongoose = require('mongoose')
var Schema = mongoose.Schema

var EventoSchema = new Schema({
    estado: {type: String}, // aberto ou fechado
    nome: {type: String}, // nome do evento
    tipo: {type: String}, // tipo de evento (futebol, patinagem)
    dataInicio: {type: String}, // data de inicio do evento
    dataFim: {type: String}, // data do fim do evento
    
    equipa:[ {      
        equipaA: {type: String},
        equipaB: {type: String} }], // correspondem à equipa
    
    odds:[ {      
        ganharA: {type: String},
        empate: {type: String},
        ganharB: {type: String} }], // correspondem às odds
    
    resultado: {type: String},
   
    jogadorID: {type: String},
    jogadorNome: {type: String},
    apostaID: {type: String}
})

module.exports = mongoose.model('Evento', EventoSchema)
