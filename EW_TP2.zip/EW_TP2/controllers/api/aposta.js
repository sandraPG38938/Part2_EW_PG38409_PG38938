var Aposta = require('../../models/api/aposta')

//listar eventos no feed
module.exports.listar = () => {
    return Aposta
        .find()
        .sort({data: -1})
        .exec()
}

/*listar proprias apostas
module.exports.verApostas = (aid) => {
    return Aposta
    .find({jogador:uid})
    .sort({data: -1})
    .exec()
}*/

//consultar eventos por id
module.exports.consultar = (aid) => {
    return Aposta
        .findOne({_id: pid})
        .exec()
}

//inserir aposta 
module.exports.inserir = aposta => {
    console.log(aposta)
    return Aposta.create(aposta)
}

//apagar aposta 
module.exports.apagar = (aid) => {
    console.log(aid)
    return Aposta
        .findOneAndRemove({_id: aid.idAposta})
}

/*editar aposta (apenas para admin)
module.exports.editar = (eid) => {
    console.log(eid)
    return Evento
       .findByIdAndUpdate({_id: eid.idEvento},{  
           $set : {
            estado: eid.estado, 
            nome: eid.nome, 
            tipo: eid.local, 
            dataInicio: eid.dataInicio,
            dataFim: eid.dataFim,
            equipa: eid.equipa,
            odds: eid.odds
       }})
} */
