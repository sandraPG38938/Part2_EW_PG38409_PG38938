var Evento = require('../../models/api/evento')

//listar eventos no feed
module.exports.listar = () => {
    return Evento
        .find()
        .sort({dataInicio: -1})
        .exec()
}

//consultar eventos por id
module.exports.consultar = (eid) => {
    return Evento
        .findOne({_id: eid})
        .exec()
}

//listar eventos por tipo de evento
module.exports.listarTipo = tipo => {
    return Evento
        .find({tipo: tipo})
        .sort({dataInicio: -1})
        .exec()
}

//inserir eventos (apenas para admin)
module.exports.inserir = evento => {
    console.log(evento)
    return Evento.create(evento)
}

/*
module.exports.equipa = (eid) => {
    console.log(eid)
    var equip = {
        equipaA: eid.equipaA,
        equipaB: eid.equipaB
    }
    return Evento
        .findByIdAndUpdate({_id: eid._id},{  $addToSet : {equipa:equip}})
} */

/*
module.exports.odds = (eid) => {
    console.log(eid)
    var odd = {
        ganharA: eid.ganharA,
        empate: eid.empate,
        ganharB: eid.ganharB
    }
    return Evento
        .findByIdAndUpdate({_id: eid._id},{  $addToSet : {odds:odd}})
} */

//apagar eventos (apenas para admin)
module.exports.apagar = (eid) => {
    console.log(eid)
    return Evento
        .findOneAndRemove({_id: eid.idEvento})
}

//editar eventos (apenas para admin)
module.exports.editar = (eid) => {
    console.log(eid)
    return Evento
       .findByIdAndUpdate({_id: eid.idEvento},{  
           $set : {
            estado: eid.estado, 
            nome: eid.nome, 
            tipo: eid.local, 
            dataInicio: eid.dataInicio,
            dataFim: eid.dataFim,
            equipa: eid.equipa,
            odds: eid.odds
       }})
} 
