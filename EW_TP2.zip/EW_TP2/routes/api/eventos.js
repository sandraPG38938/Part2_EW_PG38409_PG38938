var express = require('express')
var router = express.Router()
var Evento = require('../../controllers/api/evento')

/* GET /api/eventos */
    //para obter a lista de eventos
router.get('/', (req,res)=>{
    Evento.listar()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem dos Eventos'))
})

/* GET /api/eventos/novo */
    //para obter a lista de novos eventos
router.get('/novo', (req,res)=>{
    Evento.listar()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem das Eventos'))
})


/* UPDATE api/eventos/equipa 
router.post('/equipa', (req,res) => {
    Evento.equipa(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na consulta do Evento.'))
}) */

/* UPDATE api/eventos/odds 
router.post('/odds', (req,res) => {
    Evento.odd(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na consulta do Evento.'))
}) */

/* GET /api/evento/:eid */ 
    //para obter eventos por id
router.get('/:eid', (req,res)=>{
    Evento.consultar(req.params.eid)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na consulta da Eventos.'))
})
    
/* GET /api/evento/tipo/:t */ 
    //para obter publicações por tipo
router.get('/tipo/:t', (req,res)=>{
    Evento.listarTipo(req.params.t)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem por tipo de eventos.'))
})

/* POST api/eventos */ 
    //para criar novos eventos
router.post('/', (req,res)=>{
    Evento.inserir(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na inserção de Evento.'))
})

/* DELETE api/eventos/:eid */
router.post('/delete', (req,res) => {
    Evento.apagar(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro a apagar o Evento.'))
})

/* UPDATE api/editar/:eid */
router.post('/editar', (req,res) => {
    Evento.editar(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro a editar Evento'))
})

module.exports = router;