var express = require('express');
var router = express.Router();
var axios = require('axios');
var Eventos = require('../controllers/api/evento');

/* GET home page. */
router.get('/', (req, res) => {
  axios.get('http://localhost:3000/api/eventos')
    .then(resposta => res.render('index', { eventos: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
}); 

/* GET /eventos */
router.get('/eventos/', (req, res) => {
  axios.get('http://localhost:3000/api/eventos')
    .then(resposta => res.render('index', { eventos: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /eventos/:eid */
router.get('/eventos/:eid', (req, res) =>  {
  axios.get('http://localhost:3000/api/eventos/' + req.params.eid)
    .then(resposta => res.render('evento', { evento: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
        res.render('error', {error: erro, message: 'Erro ao carregar evento da Base de Dados'})
      })
}); 

  
/* GET /eventos/tipo/:t */
router.get('/eventos/tipo/:t', (req, res) =>  {
  axios.get('http://localhost:3000/api/eventos/tipo/' + req.params.t)
    .then(resposta => res.render('eventoTipo', { eventos: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar tipo de publicação da Base de Dados'})
    })
});

/* GET /eventos/novo */
router.get('/eventos/novo', (req, res) => {
  axios.get('http://localhost:3000/api/eventos/novo')
    .then(resposta => res.render('addEvento', { evento: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

  /* POST /eventos */
  router.post('/eventos', (req, res) =>  {
    axios.post('http://localhost:3000/api/eventos/', req.body)
      .then(() => res.redirect('http://localhost:3000/eventos'))
      .catch(erro => {
        console.log('Erro ao carregar dados da BD.')
        res.redirect('http://localhost:3000/eventos')
      })
  });

    /* UPDATE /eventos/equipa  
    router.post('/equipa', (req, res) => {
      axios.post('http://localhost:3000/api/eventos/equipa/', req.body)
        .then(resposta => res.redirect('http://localhost:3000/eventos'))
        .catch(erro => {
          console.log('Erro ao carregar dados da BD.')
          res.redirect('http://localhost:3000/eventos')
        })
    }); */
  
    /* UPDATE /eventos/odds 
    router.post('/oddds', (req, res) => {
      axios.post('http://localhost:3000/api/eventos/odds/', req.body)
        .then(resposta => res.redirect('http://localhost:3000/eventos'))
        .catch(erro => {
          console.log('Erro ao carregar dados da BD.')
          res.redirect('http://localhost:3000/eventos')
        })
    }) */ 

  /* UPDATE /eventos/editar */ 
  router.post('/editar', (req, res) => {
    axios.post('http://localhost:3000/api/eventos/editar/', req.body)
      .then(resposta => res.redirect('http://localhost:300/eventos/' + req.body.id))
      .catch(erro => {
        console.log('Erro ao carregar dados da BD.')
        res.redirect('http://localhost:3000/eventos')
      })
  });

module.exports = router;
